﻿//
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#pragma once


#ifndef __STDAFX_H_
#define __STDAFX_H_


#define STRICT


#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <stdio.h>
#include <tchar.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>

#include "D3DApp.h"
#include "resource.h"


#include "Main.h"

#endif