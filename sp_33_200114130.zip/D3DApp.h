// Interface for the CD3DApplication class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _D3DApp_H_
#define _D3DApp_H_


class CD3DApplication
{
protected:
	HINSTANCE				m_hInst			;
	HWND					m_hWnd			;

	DWORD					m_dWinStyle		;

	char					m_sCls[128]		;
	DWORD					m_dScnX			;
	DWORD					m_dScnY			;

	BOOL					m_bShowCusor	;

protected:
	LPDIRECT3D9				m_pD3D			;
	LPDIRECT3DDEVICE9		m_pd3dDevice	;
	D3DPRESENT_PARAMETERS	m_d3dParam		;
	LPD3DXSPRITE			m_pd3dSprite	;
	BOOL					m_bWindow		;

public:
	CD3DApplication();
	virtual ~CD3DApplication();

	//Window+Device���� �Լ���
	INT		Create(HINSTANCE hInst);								// Window ����
	INT		Run();													// Winodw Main Loop �Լ�
	void	Cleanup();												// ������ ���� �Լ�
	virtual	LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);			// ������ �޽��� ó���Լ�
	static	LRESULT WINAPI WndProc(HWND, UINT, WPARAM, LPARAM);		// Window Message Procedure function

public:
	virtual	HRESULT	Init();											// Game Data ����
	virtual	HRESULT	Destroy();										// Game Data �Ҹ�
	virtual	HRESULT	FrameMove();									// Game Data ����
	virtual	HRESULT	Render();										// Game Data �׸���

public:																// Application
	HINSTANCE			GetInstance(){	return m_hInst		;	}
	HWND				GetHwnd()	{	return m_hWnd		;	}
	DWORD				GetScnW()	{	return m_dScnX		;	}
	DWORD				GetScnH()	{	return m_dScnY		;	}

	LPDIRECT3DDEVICE9	GetDevice()	{	return m_pd3dDevice	;	}
	LPD3DXSPRITE		GetSprite()	{	return m_pd3dSprite	;	}
};


#endif