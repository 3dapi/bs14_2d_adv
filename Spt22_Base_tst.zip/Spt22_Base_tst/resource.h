﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// SpTool.rc에서 사용되고 있습니다.
//
#define IDI_MAIN_ICON                   101
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDD_WORK                        146
#define IDD_IMGSRC                      149
#define IDB_WORK                        150
#define IDD_SUBANI                      151
#define IDC_TX                          1013
#define IDC_PTC_TREE                    1020
#define IDC_PTC_TREE_NAME               1021
#define IDC_PTC_TREE_KIND               1022
#define IDC_PTC_TREE_SAVE               1028
#define IDC_BUTTON1                     1583
#define IDC_TAB_MERGE                   1584
#define IDC_LST_SCENE                   1585
#define IDC_LST_MSCENE                  1586
#define IDC_PREV                        1589
#define IDM_TOGGLEFULLSCREEN            40003
#define IDM_EXIT                        40006
#define IDM_NEW                         40013
#define IDM_OPEN                        40014
#define IDM_SAVE                        40015
#define IDM_ABOUT                       40017
#define ID_VIEW_SOLID                   40023
#define ID_VIEW_WIRE                    40024
#define IDM_VIEW_FIELD                  40025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        162
#define _APS_NEXT_COMMAND_VALUE         40026
#define _APS_NEXT_CONTROL_VALUE         1590
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
